import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'productFilter'
})
export class ProductFilterPipe implements PipeTransform {

  transform(value: any, args?: any): any {
    let fa = []
    value.forEach(p => {
      if (p.name.indexOf(args) != -1) {
        fa.push(p)
      }
    });
    return fa;
  }

}
