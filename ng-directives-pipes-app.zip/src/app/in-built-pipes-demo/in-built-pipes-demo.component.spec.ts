import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InBuiltPipesDemoComponent } from './in-built-pipes-demo.component';

describe('InBuiltPipesDemoComponent', () => {
  let component: InBuiltPipesDemoComponent;
  let fixture: ComponentFixture<InBuiltPipesDemoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InBuiltPipesDemoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InBuiltPipesDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
