import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-in-built-pipes-demo',
  templateUrl: './in-built-pipes-demo.component.html',
  styleUrls: ['./in-built-pipes-demo.component.css']
})
export class InBuiltPipesDemoComponent implements OnInit {

  username = "Akshay Kumar"
  orgName = "BOLLYWOOD"
  salary = 992345
  doj = new Date();
  id = 12345
  num = 123.349
  hike = 0.09;

  constructor() { }

  ngOnInit() {
  }

}
