import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-filter-skills',
  templateUrl: './filter-skills.component.html',
  styleUrls: ['./filter-skills.component.css']
})
export class FilterSkillsComponent implements OnInit {

  skill;
  skills = ['java', 'pega', 'react', 'angular', 'node', 'vuejs', 'svelte', 'nxtjs']
  constructor() { }

  ngOnInit() {
  }

}
