import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AttrDirectivesDemoComponent } from './attr-directives-demo/attr-directives-demo.component';
import { InBuiltPipesDemoComponent } from './in-built-pipes-demo/in-built-pipes-demo.component';
import { FilterPipe } from './filter.pipe';
import { FilterSkillsComponent } from './filter-skills/filter-skills.component';
import { FormsModule } from '@angular/forms';
import { ProductFilterPipe } from './product-filter.pipe'
import { HttpClientModule } from '@angular/common/http'
@NgModule({
  declarations: [
    AppComponent,
    AttrDirectivesDemoComponent,
    InBuiltPipesDemoComponent,
    FilterPipe,
    FilterSkillsComponent,
    ProductFilterPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
