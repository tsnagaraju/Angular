import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-sign-up-form',
  templateUrl: './sign-up-form.component.html',
  styleUrls: ['./sign-up-form.component.css']
})
export class SignUpFormComponent implements OnInit {

  constructor() { }

  myForm = new FormGroup({
    username: new FormControl(),
    password: new FormControl(),
    emailID: new FormControl(),
    address: new FormGroup({
      city: new FormControl(),
      state: new FormControl()
    })
  })


  ngOnInit() {
  }

}
