import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }

  user;
  pass;

  login() {
    localStorage.setItem('username', this.user)
    if (this.user === 'nagaraju' && this.pass === '123') {
      localStorage.setItem('role', 'admin')
    } else {
      localStorage.setItem('role', 'user')
    }
    this.router.navigate(['home'])
  }

}
