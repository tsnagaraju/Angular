import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor() { }

  isAuthorized(allowedRules: string[]): boolean {
    if (allowedRules == null || allowedRules.length == 0) {
      return true;
    }
    return allowedRules.includes(localStorage.getItem('role'))
  }
}
