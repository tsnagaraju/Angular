import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import { SignUpFormComponent } from './sign-up-form/sign-up-form.component';
import { FileUploadComponent } from './file-upload/file-upload.component';
import { DataValidationComponent } from './data-validation/data-validation.component';
import { LoginComponent } from './login/login.component';
import { AboutComponent } from './about/about.component';
import { HomeComponent } from './home/home.component';
import { ProductListComponent } from './product-list/product-list.component'
@NgModule({
  declarations: [
    AppComponent,
    SignUpFormComponent,
    FileUploadComponent,
    DataValidationComponent,
    LoginComponent,
    AboutComponent,
    HomeComponent,
    ProductListComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
