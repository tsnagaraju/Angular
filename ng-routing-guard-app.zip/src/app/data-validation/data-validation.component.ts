import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-data-validation',
  templateUrl: './data-validation.component.html',
  styleUrls: ['./data-validation.component.css']
})
export class DataValidationComponent implements OnInit {

  user;
  skill;
  cb1;
  cb2;
  cb3;
  pass;
  gender;

  constructor() { }

  ngOnInit() {
  }

}
