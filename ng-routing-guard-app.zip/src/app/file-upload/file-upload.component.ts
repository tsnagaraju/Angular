import { FormGroup, FormArray, FormControl } from '@angular/forms';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.css']
})
export class FileUploadComponent implements OnInit {

  myForm = new FormGroup({
    fileUp: new FormArray([])
  })

  addField() {
    //this.myForm.controls.fileUp.push(new FormControl())
  }


  removeField(ind) {
    //this.myForm.controls.fileUp.removeAt(ind)
  }
  constructor() { }

  ngOnInit() {
  }

}
