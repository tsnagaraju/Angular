import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  products = [
    { id: 1, name: 'iphone 6', price: 280, imageUrl: 'assets/images/iphone_6s.jpg' },
    { id: 2, name: 'samsung', price: 190, imageUrl: 'assets/images/iphone_6s.jpg' },
    { id: 3, name: 'iphone xs', price: 300, imageUrl: 'assets/images/iphone_6s.jpg' }

  ]
  constructor() { }

  ngOnInit() {
  }

}
