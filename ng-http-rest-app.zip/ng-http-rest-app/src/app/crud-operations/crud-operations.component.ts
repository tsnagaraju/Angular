import {HttpClient, HttpHeaders} from '@angular/common/http'

import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-crud-operations',
  templateUrl: './crud-operations.component.html',
  styleUrls: ['./crud-operations.component.css']
})
export class CRUDOperationsComponent implements OnInit {

  constructor(private http: HttpClient) {
    this.http.get("http://localhost:3000/products")
    .subscribe(
      (data)=> this.product_details=data
    )
   }

  ngOnInit() {
  }


  product_details;

  getAllProducts() {
   
  }

  addProduct() {
    var json = {name: "samsung galaxy s10", description: "mobile", price: 8999};
    var header = new HttpHeaders({'Content-Type': 'application/json'});
    this.http.post(" http://localhost:3000/products", json, {headers: header})
    .subscribe(
      ()=>{
        alert('added successfully');
        this.getAllProducts();
      }
    )
  }

  updateProduct() {
    var json  ={name: "samsung galaxy s10", description: "mobile", price: 4999}
    var header = new HttpHeaders({'Content-Type': 'application/json'})
    this.http.put(" http://localhost:3000/products/2", json, {headers: header})
    .subscribe(
      () => {
        alert("updated successfully")
        this.getAllProducts();
      }
    )

  }

  deleteProduct() {
    this.http.delete(" http://localhost:3000/products/2")
    .subscribe(
      ()=>{
        alert("deleted successfully");
        this.getAllProducts();
      }
    )
  }

  
}








