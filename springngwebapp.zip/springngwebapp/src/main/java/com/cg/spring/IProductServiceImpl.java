package com.cg.spring;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class IProductServiceImpl {

	@Autowired
	IProductRepo repo;
	
	public List<Product> getAll() {
		List<Product> list = new ArrayList();
		repo.findAll().forEach(list::add);
		return list;
	}
	
	public Product add(Product p) {
		return repo.save(p);
	}
}
