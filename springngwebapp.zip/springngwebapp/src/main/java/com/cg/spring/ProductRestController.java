package com.cg.spring;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins="http://localhost:4200")
@RestController
public class ProductRestController {

	@Autowired
	IProductServiceImpl service;
	
	@RequestMapping(value="/all", method=RequestMethod.GET)
	public List<Product> getAll() {
		return service.getAll();
	}
	
	@RequestMapping(value="/add", method=RequestMethod.POST)
	public Product addProduct(@RequestBody Product p) {
		return service.add(p);
	}
	
	
	
}
