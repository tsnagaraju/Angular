package com.cg.spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringngwebappApplicationTests {

	@Test
	void contextLoads() {
	}

}
