import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-reactive-forms-demo',
  templateUrl: './reactive-forms-demo.component.html',
  styleUrls: ['./reactive-forms-demo.component.css']
})
export class ReactiveFormsDemoComponent implements OnInit {

  constructor() { }

  myForm = new FormGroup({
    username: new FormControl(),
    password: new FormControl(),
    address: new FormGroup({
      city: new FormControl(),
      state: new FormControl()
    })
  })

  ngOnInit() {
  }

}
