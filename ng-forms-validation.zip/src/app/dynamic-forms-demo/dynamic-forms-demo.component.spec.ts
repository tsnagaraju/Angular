import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DynamicFormsDemoComponent } from './dynamic-forms-demo.component';

describe('DynamicFormsDemoComponent', () => {
  let component: DynamicFormsDemoComponent;
  let fixture: ComponentFixture<DynamicFormsDemoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DynamicFormsDemoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DynamicFormsDemoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
