import { Component, OnInit } from '@angular/core';
import { FormGroup, FormArray, FormControl } from '@angular/forms';

@Component({
  selector: 'app-dynamic-forms-demo',
  templateUrl: './dynamic-forms-demo.component.html',
  styleUrls: ['./dynamic-forms-demo.component.css']
})
export class DynamicFormsDemoComponent implements OnInit {

  constructor() { }

  myForm = new FormGroup({
    addressInput: new FormArray([])
  })

  addField() {
    this.myForm.controls.addressInput.push(new FormControl())
  }

  removeField(ind) {
    this.myForm.controls.addressInput.removeAt(ind)
  }



  ngOnInit() {
  }

}
