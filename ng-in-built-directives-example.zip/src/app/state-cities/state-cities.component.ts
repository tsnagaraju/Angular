import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-state-cities',
  templateUrl: './state-cities.component.html',
  styleUrls: ['./state-cities.component.css']
})
export class StateCitiesComponent implements OnInit {

  states = ['Telangana', 'Andhrapradesh']
  ts_cities = ['Hyderabad', 'Secunderabad']
  ap_cities = ['Vijayawada', 'Tirupathi']

  state;
  constructor() { }

  ngOnInit() {
  }

}
